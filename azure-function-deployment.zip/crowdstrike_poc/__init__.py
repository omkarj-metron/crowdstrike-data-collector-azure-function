import os
import sys
import logging
import datetime
from typing import Optional, List
from pathlib import Path

# Add parent directory to path to allow imports from src
# Handle both local and Azure deployment paths
current_dir = Path(__file__).parent
parent_dir = current_dir.parent
sys.path.insert(0, str(parent_dir))

try:
    import azure.functions as func
except ImportError as e:
    logging.error(f"Failed to import azure.functions: {e}")
    raise

try:
    from src.utils import setup_logger, get_env_config, ensure_directories
    from src.crowdstrike_manager import CrowdStrikeRTR, BloodhoundManager
    from src.rtr import process_script
except ImportError as e:
    logging.error(f"Failed to import src modules: {e}")
    logging.error(f"Current directory: {os.getcwd()}")
    logging.error(f"Python path: {sys.path}")
    logging.error(f"Parent directory: {parent_dir}")
    logging.error(f"Parent directory exists: {parent_dir.exists()}")
    raise


def main(mytimer: func.TimerRequest) -> None:
    """Azure Function v1 with timer trigger for CrowdStrike RTR data collection."""
    try:
        utc_timestamp = datetime.datetime.utcnow().replace(
            tzinfo=datetime.timezone.utc).isoformat()
        
        if mytimer.past_due:
            logging.info('The timer is past due!')
        
        logging.info('CrowdStrike RTR data collection timer trigger function executed at %s', utc_timestamp)
        logging.info('Current working directory: %s', os.getcwd())
        logging.info('Python path: %s', sys.path)
        
    except Exception as e:
        logging.exception("Error in function initialization: %s", e)
        raise
    
    try:
        # Setup required directories
        # In Azure Functions cloud, use /tmp for temporary storage or Azure Files for persistent storage
        # For local func start, use current directory
        logs_dir, rtr_result_dir = ensure_directories()
        logging.info("Logs directory: %s", logs_dir)
        logging.info("RTR results directory: %s", rtr_result_dir)

        # Load environment config
        config = get_env_config()
        script_names: List[str] = config["script_names"]
        upload_to_bh: bool = config["upload_to_bh"]
        max_retries: int = config["max_retries"]
        retry_delay: int = config["retry_delay"]

        # Setup logging for initialization steps
        init_logfile = os.path.join(logs_dir, "initialization.log")
        init_logger = setup_logger("initialization", init_logfile)
        
        # Initialize RTR client once before processing scripts
        try:
            rtr_client = CrowdStrikeRTR(logger=init_logger)
        except Exception as e:
            init_logger.exception("Failed to initialize CrowdStrikeRTR: %s", e)
            logging.error("Failed to initialize CrowdStrikeRTR: %s", e)
            return

        # Get auth token once
        init_logger.info("Step 1: Getting auth token (one time setup)")
        if not rtr_client.get_auth_token():
            init_logger.error("Failed to get authentication token. Exiting.")
            logging.error("Failed to get authentication token.")
            return

        # Fetch all devices
        init_logger.info("Step 2: Fetching all devices")
        all_devices = rtr_client.get_all_devices()
        if not all_devices:
            init_logger.error("Failed to fetch devices. Exiting.")
            logging.error("Failed to fetch devices.")
            return

        # Filter to only Windows devices
        init_logger.info("Step 3: Filtering Windows devices")
        windows_devices = rtr_client.get_windows_devices(all_devices)
        if windows_devices is None:
            init_logger.error("Failed to get device details. Exiting.")
            logging.error("Failed to get device details.")
            return

        if not windows_devices:
            init_logger.warning("No Windows devices found. Exiting.")
            logging.warning("No Windows devices found.")
            return

        init_logger.info("Found %d Windows device(s).", len(windows_devices))
        logging.info("Found %d Windows device(s).", len(windows_devices))

        # Check online status of Windows devices
        init_logger.info("Step 4: Checking online status of Windows devices")
        online_devices = rtr_client.get_online_devices(windows_devices)
        if online_devices is None:
            init_logger.error("Failed to check online status. Exiting.")
            logging.error("Failed to check online status.")
            return

        if not online_devices:
            init_logger.warning("No online Windows devices found. Exiting.")
            logging.warning("No online Windows devices found.")
            return

        init_logger.info("Found %d online Windows device(s). Processing scripts for each device.", len(online_devices))
        logging.info("Found %d online Windows device(s). Processing scripts for each device.", len(online_devices))

        # Batch initialize RTR sessions for all online Windows devices at once
        init_logger.info("Step 5: Batch initializing RTR sessions for all online Windows devices")
        device_sessions = rtr_client.batch_initialize_rtr_sessions(online_devices)
        if not device_sessions:
            init_logger.error("Failed to batch initialize RTR sessions. Exiting.")
            logging.error("Failed to batch initialize RTR sessions.")
            return

        # Filter to only devices that successfully got sessions
        devices_with_sessions = list(device_sessions.keys())
        init_logger.info("Successfully initialized sessions for %d/%d devices", 
                        len(devices_with_sessions), len(online_devices))
        logging.info("Successfully initialized sessions for %d/%d devices", 
                    len(devices_with_sessions), len(online_devices))

        # Only init BloodHound if upload is enabled
        bh_manager: Optional[BloodhoundManager] = None
        if upload_to_bh:
            try:
                bh_manager = BloodhoundManager(logger=init_logger)
            except Exception as e:
                init_logger.exception("Failed to initialize BloodhoundManager: %s", e)
                logging.error("Failed to initialize BloodhoundManager: %s", e)

        # Process each device that has a session
        for device_idx, device_id in enumerate(devices_with_sessions, start=1):
            # Create device-specific subdirectories
            device_logs_dir = os.path.join(logs_dir, device_id)
            device_rtr_result_dir = os.path.join(rtr_result_dir, device_id)
            os.makedirs(device_logs_dir, exist_ok=True)
            os.makedirs(device_rtr_result_dir, exist_ok=True)
            
            # Device-level log file in device subdirectory
            device_logfile = os.path.join(device_logs_dir, "device.log")
            device_logger = setup_logger(f"device-{device_idx}", device_logfile)
            device_logger.info("=" * 80)
            device_logger.info("Processing Device %d/%d: %s", device_idx, len(devices_with_sessions), device_id)
            device_logger.info("Session ID: %s", device_sessions[device_id])
            device_logger.info("=" * 80)

            # Process each script for this device
            for script_idx, script in enumerate(script_names, start=1):
                # Setup logging for this script on this device - store in device subdirectory
                script_logfile = os.path.join(device_logs_dir, f"{script.replace(' ', '_')}.log")
                script_logger = setup_logger(f"device-{device_idx}-script-{script_idx}", script_logfile)
                script_logger.info("--- Processing Script %d/%d: %s on Device %s ---", 
                                 script_idx, len(script_names), script, device_id)

                # Process this script - pass device-specific rtr_result_dir
                success, results = process_script(
                    script_name=script,
                    rtr_client=rtr_client,
                    bh_manager=bh_manager,
                    rtr_result_dir=device_rtr_result_dir,
                    max_retries=max_retries,
                    retry_delay=retry_delay,
                    upload_to_bh=upload_to_bh,
                    logger=script_logger,
                    device_id=device_id
                )

                if success:
                    script_logger.info("Successfully processed script %s on device %s", script, device_id)
                    logging.info("Successfully processed script %s on device %s", script, device_id)
                    if results:
                        script_logger.info("Collected %d result items", len(results))
                        logging.info("Collected %d result items", len(results))
                else:
                    script_logger.error("Failed to process script %s on device %s", script, device_id)
                    logging.error("Failed to process script %s on device %s", script, device_id)

                script_logger.info("--- Finished processing script: %s on device: %s ---\n", script, device_id)

            device_logger.info("=" * 80)
            device_logger.info("Finished processing all scripts for Device %s", device_id)
            device_logger.info("=" * 80)

        logging.info("CrowdStrike RTR data collection completed successfully")

    except Exception as e:
        logging.exception("Unhandled error in Azure Function: %s", e)
        # Re-raise to ensure Azure Functions sees this as a failure
        raise

